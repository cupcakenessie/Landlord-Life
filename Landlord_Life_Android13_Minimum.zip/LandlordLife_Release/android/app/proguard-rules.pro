# LANDLORD LIFE release rules
