# LANDLORD LIFE — Phone-first Play Store build package

This package contains:
- `web/` — offline-first mobile game/PWA
- `android/` — Android WebView wrapper targeting Android 36
- `.github/workflows/android-release.yml` — cloud build workflow for an AAB
- `PHONE_PUBLISHING.md` — phone-only publishing instructions
- `release/` — store listing and checklist materials

The Android wrapper uses the same web game assets, keeping the game code shared between the web prototype and Android package.

For iOS, the same web assets can later be wrapped in an approved iOS application project; an Apple build requires Apple's signing/build environment.


## Android release target
Minimum supported Android version: Android 13 (API 33). Target/compile SDK: Android 16 (API 36).
